#  ni_bomber
![alt text](img/test.jpg)
<br/>
<b>Hey!</b>
This is a small sms bomber, the number of<br/>
sms sent per second depends on the speed<br/>
of your internet. If you use this bomber<br/>
at the same time  by several people, you<br/>
can easily put the phone!


upd:

<b>Valid only for Russian numbers!</b>

# Install
git clone https://github.com/Nikait/ni_bomber

cd ni_bomber

pip3 install -r requirements.txt



python3 ni_bomber.py

Relax! 


#  Donate

    monero: 
    48TmwHGVsqSKgD7giTALoK7P2muKLTJn5R8s5XtKZL1jEr4MJFBAwczVtofuFGvzsT1CzTcFXotwZCDno1UsskqFFZe9wVC
***
    bitcoin:
    18LKUKWAUBAFKzLBdFFkt687vh8rMPhL1u
***
    ethereum:
    0x189a9436b2fbBd0b1C3927E8a398379DBb7105AA
